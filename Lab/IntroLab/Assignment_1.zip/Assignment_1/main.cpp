/****************************************************
 * Author           : Nicole Christensen
 * Assignment #1    : Hello World
 * Class            : CIS-17A
 * Section          : 48593
 * Due Date         : 8/29/21
 ****************************************************/

#include <iostream>
using namespace std;

/**************************************************************
 * OUTPUT HELLO WORLD
 * ____________________________________________________________
 * This program will use the stream object cout to output
 * the phrase "Hello World" onto the screen. 
 *
 **************************************************************/
int main()
{
    // Display the phrase hello world.
    cout << "Hello World!";
    return 0;
}

